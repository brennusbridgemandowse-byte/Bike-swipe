BikeSwipe prototype
===================
Open index.html in a browser. It is a mobile-first Tinder-style bicycle browser.

Current version:
- Swipe right = like
- Swipe left = pass
- Like / save / undo buttons
- Liked and Saved tabs
- Category filters
- Bike details modal
- localStorage persistence

IMPORTANT:
The included listings are demo data. To use real marketplace listings, replace the `bikes` array with a server-side feed from a marketplace API that permits this use (for example, an approved eBay Browse API integration). Never put a private API secret directly in this HTML.

Suggested production architecture:
iPhone/browser -> BikeSwipe frontend -> your backend -> marketplace API -> normalized bike listings
